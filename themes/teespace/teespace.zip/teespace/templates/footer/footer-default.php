<?php
/**
 * @package    HaruTheme
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright 2022, HaruTheme
*/
?>

<footer id="haru-footer">
    <div class="haru-container footer-default">
        <?php echo '&copy; ' . date( 'Y' ) . ' ' . esc_html( get_bloginfo() ); ?>
    </div>
</footer>
