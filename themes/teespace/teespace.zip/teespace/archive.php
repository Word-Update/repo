<?php
/**
 * @package    HaruTheme
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright 2022, HaruTheme
*/

get_header();
    get_template_part( 'templates/archive' ); // More details can see from here: http://wphierarchy.com/
get_footer();