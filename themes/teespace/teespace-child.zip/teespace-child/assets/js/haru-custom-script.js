(function ($) {
    "use strict";
    // Add your custom script here

})(jQuery);